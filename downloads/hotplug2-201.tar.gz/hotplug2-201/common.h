#ifndef COMMON_H
#define COMMON_H 1

/*
 * Various common constants and definitions.
 */

#ifndef PATH_MAX
#define PATH_MAX 1024
#endif

#endif /* COMMON_H */
